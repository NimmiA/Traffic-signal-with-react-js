import logo from './logo.svg';
import './App.css';
import TrafficSignal from "./TrafficSignal"

function App() {
  return (
    <div className="App">
  <TrafficSignal/>
    </div>
  );
}

export default App;
